### UR5 Pick and Place Simulation ###

## How it works ##
The MoveIt arm group is a chain from `base_link` to `gripper_tcp`. MoveIt plans
the arm path and checks it against the ground, pedestal and robot collision
shapes.

The left finger is controlled by `gripper_controller`. The right finger mirrors
the left finger. The finger contact boxes match the supplied finger mesh within
0.5 mm. The grip force and finger friction hold the car without making it stick
to the fingers when they open. The gripper only accepts a grasp when it stalls
in the expected contact range.

The car has a total mass of 0.325 kg. Its inertia values are calculated from
the actual box, wheel and caster sizes. Wheel friction is included so the
differential-drive plugin can move the car correctly.

After the car is released, `pick_and_place_node.py` publishes `True` on
`/trigger_car`. `car_driver_node.py` publishes a positive x velocity on
`/cmd_vel` and uses the car odometry to stop after 0.50 m.

## Simulation Overview ##
The simulation runs in this order:
  1. The UR5 moves above the car.
  2. The gripper opens.
  3. The arm lowers around the car.
  4. The fingers close against the sides of the car.
  5. The arm lifts the car and moves to the pedestal.
  6. The arm lowers the car onto the pedestal.
  7. The gripper opens and the arm moves away.
  8. The car drives forward 50 cm.
The grasp and release use Gazebo contact physics. There is no fixed-joint
attachment and the car is not moved into place with `set_pose`.


### Part 2 - Architecture ###
## Packages
# ur5_sim_package
This package contains the robot, gripper, car, pedestal, controllers and
Gazebo launch file.
Main files:
- `urdf/ur.urdf.xacro` - loads the complete UR5 and gripper.
- `urdf/ur_macro.xacro` - contains the UR5 links and joints.
- `urdf/parallel_gripper.urdf.xacro` - contains the gripper and finger contact shapes.
- `urdf/ur_control.xacro` - connects the arm and gripper to ros2_control.
- `config/controllers.yaml` - contains the arm and gripper controllers and gains.
- `models/two_wheel_car.sdf` - contains the car, wheels and drive plugin.
- `models/assignment_environment.sdf` - contains the ground and pedestal.
- `launch/ur5.launch.py` - starts Gazebo, spawns the models and starts the controllers.
- `scripts/measure_arm_tracking.py` - measures arm position error.
- `scripts/measure_gripper_tracking.py` - measures gripper position error.

# ur5_moveit_config
This package contains MoveIt, RViz and the automatic task.
Main files:
- `config/group4_ur5.srdf` - defines the arm group, gripper group and named poses.
- `config/moveit_controllers.yaml` - connects MoveIt to the ROS controllers.
- `config/planning_scene_objects.yaml` - adds the ground, car and pedestal to MoveIt.
- `config/kinematics.yaml` - contains the inverse kinematics settings.
- `config/ompl_planning.yaml` - contains the motion planner settings.
- `launch/moveit.launch.py` - starts Gazebo, MoveIt and RViz for manual control.
- `launch/pick_and_place.launch.py` - starts the complete automatic task.
- `scripts/pick_and_place_node.py` - runs the eight pick-and-place states.
- `scripts/car_driver_node.py` - drives the car after `/trigger_car` is received.
- `scripts/planning_scene_obstacles.py` - sends the collision objects to MoveIt.
- `scripts/run_pick_and_place_quiet` - hides normal ROS output and keeps the state messages, warnings and errors.

# Other source packages
- `moveit_py` - MoveIt Python bindings for ROS 2 Humble.
- `ur_msgs` - Universal Robots message and service definitions.



### Part 3 - Operation Readme ###

## 1. Folder layout
Put all four folders inside `group4_ws/src`:
```text
group4_ws/
└── src/
    ├── moveit_py/
    ├── ur5_moveit_config/
    ├── ur5_sim_package/
    └── ur_msgs/
```


## 2. Install the required programs
This assumes the official ROS 2 Humble repository is already set up on Ubuntu
22.04.

```bash
sudo apt update
sudo apt install -y \
  ros-humble-desktop \
  ros-humble-moveit \
  ros-humble-ros-gz \
  ros-humble-gz-ros2-control \
  ros-humble-ros2-control \
  ros-humble-ros2-controllers \
  ros-humble-ur \
  python3-colcon-common-extensions \
  python3-rosdep \
  python3-yaml
```

Install the package dependencies:
```bash
source /opt/ros/humble/setup.bash
# Only run this once on a new computer.
sudo rosdep init
rosdep update
export WS=~/group4_ws
cd "$WS"
rosdep install --from-paths src --ignore-src --rosdistro humble -r -y
```


## 3. Build the workspace
```bash
export WS=~/group4_ws  
cd "$WS"
source /opt/ros/humble/setup.bash
colcon build \
  --symlink-install \
  --packages-up-to ur5_moveit_config
source "$WS/install/setup.bash"
```


## 4. Run the automatic simulation
This starts Gazebo, MoveIt, RViz, the controllers, the pick-and-place node and
the car driver. Wait for the blue state messages in the terminal:
```bash
export WS=~/group4_ws
cd "$WS"
source /opt/ros/humble/setup.bash
source "$WS/install/setup.bash"
ros2 run ur5_moveit_config run_pick_and_place_quiet
```

To show all ROS and Gazebo output instead, run:
```bash
ros2 launch ur5_moveit_config pick_and_place.launch.py
```

Stop the simulation with `Ctrl+C`.


## Use MoveIt manually
```bash
export WS=~/group4_ws
cd "$WS"
source /opt/ros/humble/setup.bash
source "$WS/install/setup.bash"
ros2 launch ur5_moveit_config moveit.launch.py
```

In RViz, open the MotionPlanning panel, select `ur_manipulator`, move the
`gripper_tcp` marker, then press **Plan** and **Execute**. Select the `gripper`
group to use its `open` and `closed` poses.

## Basic checks
```bash
ros2 control list_controllers
ros2 action list
ros2 topic echo /joint_states --once
```

The active controllers should be:
```text
joint_state_broadcaster
arm_controller
gripper_controller
```
